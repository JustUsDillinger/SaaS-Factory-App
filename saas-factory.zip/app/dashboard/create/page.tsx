import AuthGuard from "@/components/auth-guard"
import DashboardLayout from "@/components/dashboard-layout"
import AppGenerationForm from "@/components/app-generation-form"

export default function CreateAppPage() {
  return (
    <AuthGuard>
      <DashboardLayout activeTab="create-app">
        <AppGenerationForm />
      </DashboardLayout>
    </AuthGuard>
  )
}
