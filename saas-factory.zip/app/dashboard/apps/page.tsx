import AuthGuard from "@/components/auth-guard"
import DashboardLayout from "@/components/dashboard-layout"
import AppManagementTable from "@/components/app-management-table"

export default function AppsPage() {
  return (
    <AuthGuard>
      <DashboardLayout activeTab="dashboard">
        <AppManagementTable />
      </DashboardLayout>
    </AuthGuard>
  )
}
