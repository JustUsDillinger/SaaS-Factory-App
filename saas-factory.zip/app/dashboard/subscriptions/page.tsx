import AuthGuard from "@/components/auth-guard"
import DashboardLayout from "@/components/dashboard-layout"
import SubscriptionManagement from "@/components/subscription-management"

export default function SubscriptionsPage() {
  return (
    <AuthGuard>
      <DashboardLayout activeTab="subscriptions">
        <SubscriptionManagement />
      </DashboardLayout>
    </AuthGuard>
  )
}
