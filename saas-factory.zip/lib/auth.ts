// Authentication utilities for SaaS Factory
// Note: This is a mock implementation until Supabase is integrated

export interface User {
  id: string
  email: string
  name: string
}

export interface AuthState {
  user: User | null
  loading: boolean
}

// Mock user for demo purposes
const MOCK_USER: User = {
  id: "1",
  email: "admin@saas-factory.com",
  name: "Admin User",
}

export async function signIn(email: string, password: string): Promise<User> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Mock authentication - in production, this would use Supabase
  if (email === "admin@saas-factory.com" && password === "password") {
    localStorage.setItem("auth-user", JSON.stringify(MOCK_USER))
    return MOCK_USER
  }

  throw new Error("Invalid credentials")
}

export async function signOut(): Promise<void> {
  localStorage.removeItem("auth-user")
}

export function getCurrentUser(): User | null {
  if (typeof window === "undefined") return null

  const stored = localStorage.getItem("auth-user")
  if (!stored) return null

  try {
    return JSON.parse(stored)
  } catch {
    return null
  }
}

export function isAuthenticated(): boolean {
  return getCurrentUser() !== null
}
