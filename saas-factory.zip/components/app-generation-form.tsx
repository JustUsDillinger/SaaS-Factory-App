"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Sparkles, ArrowLeft, CheckCircle, Clock, Zap } from "lucide-react"

interface GeneratedApp {
  id: string
  name: string
  niche: string
  description: string
  landingPageUrl: string
  signupUrl: string
  paymentLink: string
}

const nicheExamples = [
  "Barber booking system",
  "Tutor scheduling platform",
  "Pet grooming appointments",
  "Yoga class reservations",
  "Car wash booking",
  "Photography session scheduler",
  "Meal prep delivery",
  "Home cleaning service",
  "Personal trainer booking",
  "Music lesson scheduler",
]

export default function AppGenerationForm() {
  const [formData, setFormData] = useState({
    niche: "",
    appName: "",
    description: "",
  })
  const [loading, setLoading] = useState(false)
  const [generatedApp, setGeneratedApp] = useState<GeneratedApp | null>(null)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      // Simulate app generation process
      await new Promise((resolve) => setTimeout(resolve, 3000))

      // Mock generated app data
      const mockApp: GeneratedApp = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.appName || `${formData.niche.split(" ")[0]}Pro`,
        niche: formData.niche,
        description: formData.description,
        landingPageUrl: `https://${formData.niche.toLowerCase().replace(/\s+/g, "")}.vercel.app`,
        signupUrl: `https://${formData.niche.toLowerCase().replace(/\s+/g, "")}.vercel.app/signup`,
        paymentLink: `https://buy.stripe.com/mock-${Math.random().toString(36).substr(2, 9)}`,
      }

      setGeneratedApp(mockApp)
    } catch (err) {
      setError("Failed to generate app. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  const handleReset = () => {
    setFormData({ niche: "", appName: "", description: "" })
    setGeneratedApp(null)
    setError("")
  }

  if (generatedApp) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={handleReset}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Create Another
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">App Generated Successfully!</h1>
            <p className="text-muted-foreground">Your new SaaS app is ready to launch</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <CardTitle className="text-green-700">{generatedApp.name}</CardTitle>
            </div>
            <CardDescription>{generatedApp.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Landing Page</Label>
                <div className="flex items-center gap-2">
                  <Input value={generatedApp.landingPageUrl} readOnly className="text-sm" />
                  <Button size="sm" variant="outline" asChild>
                    <a href={generatedApp.landingPageUrl} target="_blank" rel="noopener noreferrer">
                      View
                    </a>
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Signup Page</Label>
                <div className="flex items-center gap-2">
                  <Input value={generatedApp.signupUrl} readOnly className="text-sm" />
                  <Button size="sm" variant="outline" asChild>
                    <a href={generatedApp.signupUrl} target="_blank" rel="noopener noreferrer">
                      View
                    </a>
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Payment Link</Label>
                <div className="flex items-center gap-2">
                  <Input value={generatedApp.paymentLink} readOnly className="text-sm" />
                  <Button size="sm" variant="outline" asChild>
                    <a href={generatedApp.paymentLink} target="_blank" rel="noopener noreferrer">
                      View
                    </a>
                  </Button>
                </div>
              </div>
            </div>

            <Alert>
              <Zap className="h-4 w-4" />
              <AlertDescription>
                Your app has been deployed and is ready to accept customers. The subscription system is automatically
                configured for $29/month per user.
              </AlertDescription>
            </Alert>

            <div className="flex gap-2">
              <Button asChild>
                <a href="/dashboard">View Dashboard</a>
              </Button>
              <Button variant="outline" onClick={handleReset}>
                Create Another App
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Create New SaaS App</h1>
        <p className="text-muted-foreground">Generate a complete mini SaaS application in minutes</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                App Generation Form
              </CardTitle>
              <CardDescription>Describe your SaaS idea and we'll generate a complete application</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="niche">Niche Idea *</Label>
                  <Input
                    id="niche"
                    value={formData.niche}
                    onChange={(e) => setFormData({ ...formData, niche: e.target.value })}
                    placeholder="e.g., barber booking system, tutor scheduler"
                    required
                  />
                  <p className="text-sm text-muted-foreground">
                    Describe the type of business or service your SaaS will serve
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="appName">App Name (Optional)</Label>
                  <Input
                    id="appName"
                    value={formData.appName}
                    onChange={(e) => setFormData({ ...formData, appName: e.target.value })}
                    placeholder="Leave blank to auto-generate"
                  />
                  <p className="text-sm text-muted-foreground">We'll create a name if you leave this blank</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Additional Details (Optional)</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Any specific features or requirements..."
                    rows={4}
                  />
                </div>

                <Button type="submit" className="w-full" disabled={loading || !formData.niche.trim()}>
                  {loading ? (
                    <>
                      <Clock className="mr-2 h-4 w-4 animate-spin" />
                      Generating App...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Generate SaaS App
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Popular Niches</CardTitle>
              <CardDescription>Click any example to use as inspiration</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {nicheExamples.map((example) => (
                  <Badge
                    key={example}
                    variant="outline"
                    className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
                    onClick={() => setFormData({ ...formData, niche: example })}
                  >
                    {example}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">What You Get</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Complete Landing Page</p>
                  <p className="text-xs text-muted-foreground">Professional design with your branding</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">User Signup System</p>
                  <p className="text-xs text-muted-foreground">Authentication and user management</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Stripe Payment Integration</p>
                  <p className="text-xs text-muted-foreground">$29/month subscription ready</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sm">Deployed & Live</p>
                  <p className="text-xs text-muted-foreground">Ready to accept customers immediately</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
