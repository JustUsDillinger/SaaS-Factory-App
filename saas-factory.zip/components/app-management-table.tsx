"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { MoreHorizontal, Search, Plus, ExternalLink, Pause, Play, Trash2, Edit } from "lucide-react"

interface App {
  id: string
  name: string
  niche: string
  status: "Active" | "Paused"
  monthlyRevenue: number
  subscribers: number
  landingPageUrl: string
  signupUrl: string
  paymentLink: string
  createdAt: string
  updatedAt: string
}

// Mock data for demonstration
const mockApps: App[] = [
  {
    id: "1",
    name: "BarberBook Pro",
    niche: "Barber booking system",
    status: "Active",
    monthlyRevenue: 1250,
    subscribers: 42,
    landingPageUrl: "https://barberbook.vercel.app",
    signupUrl: "https://barberbook.vercel.app/signup",
    paymentLink: "https://buy.stripe.com/barberbook",
    createdAt: "2024-01-15",
    updatedAt: "2024-01-20",
  },
  {
    id: "2",
    name: "TutorConnect",
    niche: "Tutor scheduling platform",
    status: "Active",
    monthlyRevenue: 890,
    subscribers: 28,
    landingPageUrl: "https://tutorconnect.vercel.app",
    signupUrl: "https://tutorconnect.vercel.app/signup",
    paymentLink: "https://buy.stripe.com/tutorconnect",
    createdAt: "2024-01-20",
    updatedAt: "2024-01-25",
  },
  {
    id: "3",
    name: "FitTracker",
    niche: "Personal fitness tracking",
    status: "Paused",
    monthlyRevenue: 0,
    subscribers: 15,
    landingPageUrl: "https://fittracker.vercel.app",
    signupUrl: "https://fittracker.vercel.app/signup",
    paymentLink: "https://buy.stripe.com/fittracker",
    createdAt: "2024-01-25",
    updatedAt: "2024-01-30",
  },
  {
    id: "4",
    name: "PetGroomer Plus",
    niche: "Pet grooming appointments",
    status: "Active",
    monthlyRevenue: 650,
    subscribers: 19,
    landingPageUrl: "https://petgroomer.vercel.app",
    signupUrl: "https://petgroomer.vercel.app/signup",
    paymentLink: "https://buy.stripe.com/petgroomer",
    createdAt: "2024-02-01",
    updatedAt: "2024-02-05",
  },
  {
    id: "5",
    name: "YogaFlow",
    niche: "Yoga class reservations",
    status: "Active",
    monthlyRevenue: 1100,
    subscribers: 35,
    landingPageUrl: "https://yogaflow.vercel.app",
    signupUrl: "https://yogaflow.vercel.app/signup",
    paymentLink: "https://buy.stripe.com/yogaflow",
    createdAt: "2024-02-05",
    updatedAt: "2024-02-10",
  },
]

export default function AppManagementTable() {
  const [apps, setApps] = useState<App[]>(mockApps)
  const [searchTerm, setSearchTerm] = useState("")

  const filteredApps = apps.filter(
    (app) =>
      app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.niche.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const toggleAppStatus = (appId: string) => {
    setApps((prevApps) =>
      prevApps.map((app) =>
        app.id === appId
          ? {
              ...app,
              status: app.status === "Active" ? "Paused" : "Active",
              monthlyRevenue: app.status === "Active" ? 0 : app.monthlyRevenue,
              updatedAt: new Date().toISOString().split("T")[0],
            }
          : app,
      ),
    )
  }

  const deleteApp = (appId: string) => {
    setApps((prevApps) => prevApps.filter((app) => app.id !== appId))
  }

  const totalRevenue = filteredApps.reduce((sum, app) => sum + app.monthlyRevenue, 0)
  const totalSubscribers = filteredApps.reduce((sum, app) => sum + app.subscribers, 0)
  const activeApps = filteredApps.filter((app) => app.status === "Active").length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">App Management</h1>
          <p className="text-muted-foreground">Manage all your generated SaaS applications</p>
        </div>
        <Button asChild>
          <a href="/dashboard/create">
            <Plus className="mr-2 h-4 w-4" />
            Create New App
          </a>
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Apps</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredApps.length}</div>
            <p className="text-xs text-muted-foreground">{activeApps} active</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Across all apps</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Subscribers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalSubscribers}</div>
            <p className="text-xs text-muted-foreground">Active users</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Table */}
      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle>All Apps</CardTitle>
              <CardDescription>View and manage your SaaS applications</CardDescription>
            </div>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search apps..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>App Name</TableHead>
                  <TableHead>Niche</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Revenue</TableHead>
                  <TableHead className="text-right">Subscribers</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredApps.map((app) => (
                  <TableRow key={app.id}>
                    <TableCell className="font-medium">{app.name}</TableCell>
                    <TableCell className="text-muted-foreground">{app.niche}</TableCell>
                    <TableCell>
                      <Badge variant={app.status === "Active" ? "default" : "secondary"}>{app.status}</Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono">${app.monthlyRevenue.toLocaleString()}/mo</TableCell>
                    <TableCell className="text-right">{app.subscribers}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(app.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <a href={app.landingPageUrl} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="mr-2 h-4 w-4" />
                              View Landing Page
                            </a>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <a href={app.signupUrl} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="mr-2 h-4 w-4" />
                              View Signup Page
                            </a>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <a href={app.paymentLink} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="mr-2 h-4 w-4" />
                              View Payment Link
                            </a>
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => toggleAppStatus(app.id)}>
                            {app.status === "Active" ? (
                              <>
                                <Pause className="mr-2 h-4 w-4" />
                                Pause App
                              </>
                            ) : (
                              <>
                                <Play className="mr-2 h-4 w-4" />
                                Activate App
                              </>
                            )}
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit Details
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => deleteApp(app.id)}
                            className="text-destructive focus:text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete App
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {filteredApps.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">
                {searchTerm ? "No apps match your search" : "No apps created yet"}
              </p>
              {!searchTerm && (
                <Button asChild>
                  <a href="/dashboard/create">
                    <Plus className="mr-2 h-4 w-4" />
                    Create Your First App
                  </a>
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
