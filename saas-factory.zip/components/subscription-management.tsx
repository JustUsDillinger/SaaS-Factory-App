"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { CreditCard, DollarSign, TrendingUp, AlertCircle, CheckCircle, XCircle } from "lucide-react"

interface Subscription {
  id: string
  appName: string
  appId: string
  stripeSubscriptionId: string
  stripeCustomerId: string
  status: "active" | "canceled" | "past_due" | "unpaid"
  currentPeriodStart: string
  currentPeriodEnd: string
  amount: number
  currency: string
  customerEmail: string
  customerName: string
}

// Mock subscription data
const mockSubscriptions: Subscription[] = [
  {
    id: "1",
    appName: "BarberBook Pro",
    appId: "app_1",
    stripeSubscriptionId: "sub_1234567890",
    stripeCustomerId: "cus_1234567890",
    status: "active",
    currentPeriodStart: "2024-02-01",
    currentPeriodEnd: "2024-03-01",
    amount: 29.0,
    currency: "USD",
    customerEmail: "john@barbershop.com",
    customerName: "John's Barbershop",
  },
  {
    id: "2",
    appName: "BarberBook Pro",
    appId: "app_1",
    stripeSubscriptionId: "sub_0987654321",
    stripeCustomerId: "cus_0987654321",
    status: "active",
    currentPeriodStart: "2024-02-05",
    currentPeriodEnd: "2024-03-05",
    amount: 29.0,
    currency: "USD",
    customerEmail: "mike@cutandstyle.com",
    customerName: "Mike's Cut & Style",
  },
  {
    id: "3",
    appName: "TutorConnect",
    appId: "app_2",
    stripeSubscriptionId: "sub_1122334455",
    stripeCustomerId: "cus_1122334455",
    status: "past_due",
    currentPeriodStart: "2024-01-15",
    currentPeriodEnd: "2024-02-15",
    amount: 29.0,
    currency: "USD",
    customerEmail: "sarah@mathtutor.com",
    customerName: "Sarah's Math Tutoring",
  },
  {
    id: "4",
    appName: "YogaFlow",
    appId: "app_5",
    stripeSubscriptionId: "sub_5566778899",
    stripeCustomerId: "cus_5566778899",
    status: "active",
    currentPeriodStart: "2024-02-10",
    currentPeriodEnd: "2024-03-10",
    amount: 29.0,
    currency: "USD",
    customerEmail: "zen@yogastudio.com",
    customerName: "Zen Yoga Studio",
  },
  {
    id: "5",
    appName: "PetGroomer Plus",
    appId: "app_4",
    stripeSubscriptionId: "sub_9988776655",
    stripeCustomerId: "cus_9988776655",
    status: "canceled",
    currentPeriodStart: "2024-01-01",
    currentPeriodEnd: "2024-02-01",
    amount: 29.0,
    currency: "USD",
    customerEmail: "pets@groomingplace.com",
    customerName: "The Grooming Place",
  },
]

const getStatusIcon = (status: string) => {
  switch (status) {
    case "active":
      return <CheckCircle className="h-4 w-4 text-green-500" />
    case "past_due":
      return <AlertCircle className="h-4 w-4 text-yellow-500" />
    case "canceled":
    case "unpaid":
      return <XCircle className="h-4 w-4 text-red-500" />
    default:
      return <AlertCircle className="h-4 w-4 text-gray-500" />
  }
}

const getStatusVariant = (status: string): "default" | "secondary" | "destructive" => {
  switch (status) {
    case "active":
      return "default"
    case "past_due":
      return "secondary"
    case "canceled":
    case "unpaid":
      return "destructive"
    default:
      return "secondary"
  }
}

export default function SubscriptionManagement() {
  const [subscriptions] = useState<Subscription[]>(mockSubscriptions)

  const activeSubscriptions = subscriptions.filter((sub) => sub.status === "active")
  const totalMRR = activeSubscriptions.reduce((sum, sub) => sum + sub.amount, 0)
  const pastDueCount = subscriptions.filter((sub) => sub.status === "past_due").length
  const canceledCount = subscriptions.filter((sub) => sub.status === "canceled").length

  // Group subscriptions by app
  const subscriptionsByApp = subscriptions.reduce(
    (acc, sub) => {
      if (!acc[sub.appName]) {
        acc[sub.appName] = []
      }
      acc[sub.appName].push(sub)
      return acc
    },
    {} as Record<string, Subscription[]>,
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Subscription Management</h1>
        <p className="text-muted-foreground">Monitor and manage all app subscriptions</p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Monthly Recurring Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">${totalMRR.toLocaleString()}</div>
            <p className="text-xs text-primary mt-1 font-medium">+12% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Subscriptions</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{activeSubscriptions.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Paying customers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Past Due</CardTitle>
            <AlertCircle className="h-4 w-4 text-yellow-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{pastDueCount}</div>
            <p className="text-xs text-muted-foreground mt-1">Need attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Churn Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {((canceledCount / subscriptions.length) * 100).toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground mt-1">This month</p>
          </CardContent>
        </Card>
      </div>

      {/* Alerts */}
      {pastDueCount > 0 && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            You have {pastDueCount} subscription{pastDueCount > 1 ? "s" : ""} past due. Consider reaching out to these
            customers to resolve payment issues.
          </AlertDescription>
        </Alert>
      )}

      {/* Revenue by App */}
      <Card>
        <CardHeader>
          <CardTitle>Revenue by App</CardTitle>
          <CardDescription>Monthly recurring revenue breakdown</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {Object.entries(subscriptionsByApp).map(([appName, subs]) => {
            const appMRR = subs.filter((s) => s.status === "active").reduce((sum, s) => sum + s.amount, 0)
            const appProgress = (appMRR / totalMRR) * 100

            return (
              <div key={appName} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{appName}</span>
                  <span className="text-sm text-muted-foreground">
                    ${appMRR.toLocaleString()}/mo ({subs.filter((s) => s.status === "active").length} subscribers)
                  </span>
                </div>
                <Progress value={appProgress} className="h-2" />
              </div>
            )
          })}
        </CardContent>
      </Card>

      {/* All Subscriptions Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Subscriptions</CardTitle>
          <CardDescription>Complete list of customer subscriptions across all apps</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Customer</TableHead>
                  <TableHead>App</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead>Current Period</TableHead>
                  <TableHead>Stripe ID</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {subscriptions.map((subscription) => (
                  <TableRow key={subscription.id}>
                    <TableCell>
                      <div>
                        <div className="font-medium">{subscription.customerName}</div>
                        <div className="text-sm text-muted-foreground">{subscription.customerEmail}</div>
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{subscription.appName}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(subscription.status)}
                        <Badge variant={getStatusVariant(subscription.status)}>
                          {subscription.status.replace("_", " ")}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      ${subscription.amount.toFixed(2)}/{subscription.currency === "USD" ? "mo" : "mo"}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(subscription.currentPeriodStart).toLocaleDateString()} -{" "}
                      {new Date(subscription.currentPeriodEnd).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {subscription.stripeSubscriptionId}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {subscriptions.length === 0 && (
            <div className="text-center py-8">
              <CreditCard className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-4">No subscriptions yet</p>
              <p className="text-sm text-muted-foreground">
                Subscriptions will appear here once customers start paying for your apps
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
