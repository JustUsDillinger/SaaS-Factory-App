"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Settings, CreditCard, Key, AlertTriangle, CheckCircle } from "lucide-react"

export default function SettingsPage() {
  const [profileData, setProfileData] = useState({
    name: "Admin User",
    email: "admin@saas-factory.com",
    company: "SaaS Factory Inc.",
  })

  const [stripeConnected, setStripeConnected] = useState(false)
  const [supabaseConnected, setSupabaseConnected] = useState(false)

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle profile update
    console.log("[v0] Profile updated:", profileData)
  }

  const connectStripe = () => {
    // Handle Stripe connection
    setStripeConnected(true)
  }

  const connectSupabase = () => {
    // Handle Supabase connection
    setSupabaseConnected(true)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">Settings</h1>
        <p className="text-muted-foreground">Manage your account and integration settings</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-6">
          {/* Profile Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Profile Settings
              </CardTitle>
              <CardDescription>Update your personal information</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProfileUpdate} className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={profileData.name}
                      onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={profileData.email}
                      onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company">Company Name</Label>
                  <Input
                    id="company"
                    value={profileData.company}
                    onChange={(e) => setProfileData({ ...profileData, company: e.target.value })}
                  />
                </div>
                <Button type="submit">Update Profile</Button>
              </form>
            </CardContent>
          </Card>

          {/* Integration Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-5 w-5" />
                Integrations
              </CardTitle>
              <CardDescription>Connect external services to power your SaaS apps</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Stripe Integration */}
              <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="flex items-center gap-3">
                  <CreditCard className="h-8 w-8 text-primary" />
                  <div>
                    <h3 className="font-semibold">Stripe</h3>
                    <p className="text-sm text-muted-foreground">Payment processing for your apps</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {stripeConnected ? (
                    <>
                      <Badge variant="default" className="bg-green-100 text-green-800">
                        <CheckCircle className="mr-1 h-3 w-3" />
                        Connected
                      </Badge>
                      <Button variant="outline" size="sm">
                        Configure
                      </Button>
                    </>
                  ) : (
                    <>
                      <Badge variant="secondary">Not Connected</Badge>
                      <Button size="sm" onClick={connectStripe}>
                        Connect
                      </Button>
                    </>
                  )}
                </div>
              </div>

              {/* Supabase Integration */}
              <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 bg-green-500 rounded flex items-center justify-center">
                    <span className="text-white font-bold text-sm">S</span>
                  </div>
                  <div>
                    <h3 className="font-semibold">Supabase</h3>
                    <p className="text-sm text-muted-foreground">Database and authentication</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {supabaseConnected ? (
                    <>
                      <Badge variant="default" className="bg-green-100 text-green-800">
                        <CheckCircle className="mr-1 h-3 w-3" />
                        Connected
                      </Badge>
                      <Button variant="outline" size="sm">
                        Configure
                      </Button>
                    </>
                  ) : (
                    <>
                      <Badge variant="secondary">Not Connected</Badge>
                      <Button size="sm" onClick={connectSupabase}>
                        Connect
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {/* Account Status */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Account Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm">Plan</span>
                <Badge>Pro</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Apps Created</span>
                <span className="text-sm font-medium">5</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Total Revenue</span>
                <span className="text-sm font-medium">$3,890</span>
              </div>
              <Separator />
              <Button variant="outline" className="w-full bg-transparent">
                Upgrade Plan
              </Button>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button variant="outline" className="w-full justify-start bg-transparent">
                Export Data
              </Button>
              <Button variant="outline" className="w-full justify-start bg-transparent">
                API Documentation
              </Button>
              <Button variant="outline" className="w-full justify-start bg-transparent">
                Contact Support
              </Button>
              <Separator />
              <Button variant="destructive" className="w-full justify-start">
                <AlertTriangle className="mr-2 h-4 w-4" />
                Delete Account
              </Button>
            </CardContent>
          </Card>

          {/* Integration Status */}
          {(!stripeConnected || !supabaseConnected) && (
            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Complete your integrations to start generating fully functional SaaS apps.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </div>
    </div>
  )
}
