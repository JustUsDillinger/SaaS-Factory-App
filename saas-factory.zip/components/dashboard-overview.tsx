"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, TrendingUp, Users, DollarSign, Zap } from "lucide-react"

// Mock data for demonstration
const mockApps = [
  {
    id: "1",
    name: "BarberBook Pro",
    niche: "Barber booking system",
    status: "Active" as const,
    monthlyRevenue: 1250,
    subscribers: 42,
    createdAt: "2024-01-15",
  },
  {
    id: "2",
    name: "TutorConnect",
    niche: "Tutor scheduling platform",
    status: "Active" as const,
    monthlyRevenue: 890,
    subscribers: 28,
    createdAt: "2024-01-20",
  },
  {
    id: "3",
    name: "FitTracker",
    niche: "Personal fitness tracking",
    status: "Paused" as const,
    monthlyRevenue: 0,
    subscribers: 15,
    createdAt: "2024-01-25",
  },
]

const stats = [
  {
    title: "Total Apps",
    value: mockApps.length.toString(),
    description: "Generated mini apps",
    icon: Zap,
    trend: "+2 this month",
  },
  {
    title: "Active Apps",
    value: mockApps.filter((app) => app.status === "Active").length.toString(),
    description: "Currently running",
    icon: TrendingUp,
    trend: "67% active rate",
  },
  {
    title: "Total Revenue",
    value: `$${mockApps.reduce((sum, app) => sum + app.monthlyRevenue, 0).toLocaleString()}`,
    description: "Monthly recurring revenue",
    icon: DollarSign,
    trend: "+12% from last month",
  },
  {
    title: "Total Subscribers",
    value: mockApps.reduce((sum, app) => sum + app.subscribers, 0).toString(),
    description: "Across all apps",
    icon: Users,
    trend: "+23 this month",
  },
]

export default function DashboardOverview() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Manage your SaaS apps and track performance</p>
        </div>
        <Button asChild className="sm:w-auto">
          <a href="/dashboard/create">
            <Plus className="mr-2 h-4 w-4" />
            Create New App
          </a>
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                <Icon className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>
                <p className="text-xs text-primary mt-1 font-medium">{stat.trend}</p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Recent Apps */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Apps</CardTitle>
          <CardDescription>Your latest generated SaaS applications</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockApps.map((app) => (
              <div
                key={app.id}
                className="flex flex-col gap-3 p-4 border border-border rounded-lg sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-foreground">{app.name}</h3>
                    <Badge variant={app.status === "Active" ? "default" : "secondary"}>{app.status}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{app.niche}</p>
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span>${app.monthlyRevenue}/mo</span>
                    <span>{app.subscribers} subscribers</span>
                    <span>Created {new Date(app.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                  <Button variant="outline" size="sm">
                    {app.status === "Active" ? "Pause" : "Activate"}
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {mockApps.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">No apps created yet</p>
              <Button asChild>
                <a href="/dashboard/create">
                  <Plus className="mr-2 h-4 w-4" />
                  Create Your First App
                </a>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
